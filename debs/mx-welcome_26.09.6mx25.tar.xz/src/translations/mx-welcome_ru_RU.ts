<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>Backend</name>
    <message>
        <location filename="../src/backend.cpp" line="74"/>
        <location filename="../src/backend.cpp" line="95"/>
        <location filename="../src/backend.cpp" line="118"/>
        <location filename="../src/backend.cpp" line="315"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="74"/>
        <source>Could not update the login startup setting.</source>
        <translation>Не удалось обновить параметры автозапуска при входе в систему.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="95"/>
        <source>Could not open %1</source>
        <translation>Не удалось открыть %1</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="106"/>
        <source>System information is unavailable.</source>
        <translation>Информация о системе недоступна.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="118"/>
        <source>Could not start Quick System Info.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="129"/>
        <source>Could not load the Terms of Use.</source>
        <translation>Не удалось загрузить &quot;Условия использования&quot;.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="136"/>
        <source>Could not load %1</source>
        <translation>Не удалось загрузить %1</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="146"/>
        <source>Could not load changelog.</source>
        <translation>Не удалось загрузить список изменений.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="197"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>Название «MX Linux» подпадает под сублицензию Linux Foundation No. 20140605-0483. Мы разрабатываем программное обеспечение, на которое распространяется бесплатная лицензия, доступная в списке Вики. Мы также включаем программное обеспечение, разработанное другими, которое также имеет бесплатную лицензию.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="208"/>
        <source>User demo, password: demo. Superuser root, password: root.</source>
        <translation>Пользователь demo, пароль: demo. Суперпользователь root, пароль: root.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="228"/>
        <source>%1 “%2”</source>
        <translation>%1 “%2”</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Install MX Linux</source>
        <translation>Установить MX Linux</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Install MX Linux on this computer.</source>
        <translation>Установите MX Linux на этот компьютер.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="263"/>
        <source>FAQ</source>
        <translation>ЧаВо</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="263"/>
        <source>Find answers to frequently asked questions.</source>
        <translation>Найдите ответы на часто задаваемые вопросы.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="264"/>
        <source>Forums</source>
        <translation>Форумы</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="264"/>
        <source>Ask questions and join the MX Linux community.</source>
        <translation>Задавайте вопросы и присоединяйтесь к сообществу MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="265"/>
        <source>Users Manual</source>
        <translation>Руководство пользователя</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="265"/>
        <source>Read the documentation for your MX Linux release.</source>
        <translation>Ознакомьтесь с документацией к вашей версии MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="266"/>
        <source>Videos</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="266"/>
        <source>Watch MX Linux tutorials and demonstrations.</source>
        <translation>Смотрите обучающие и демонстрационные ролики по MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="267"/>
        <source>Wiki</source>
        <translation>Вики</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="267"/>
        <source>Browse community-maintained guides and reference material.</source>
        <translation>Просмотрите созданные сообществом руководства и справочные материалы.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="268"/>
        <source>Contribute</source>
        <translation>Поддержать</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="268"/>
        <source>Learn how to support and contribute to MX Linux.</source>
        <translation>Узнайте, как поддерживать и вносить свой вклад в развитие MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="269"/>
        <source>Tools</source>
        <translation>Инструменты</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="269"/>
        <source>Open the collection of MX system utilities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="270"/>
        <source>Popular Apps</source>
        <translation>Популярные приложения</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="270"/>
        <source>Discover and install popular applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="271"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Настройка (панели и пр.)</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="271"/>
        <source>Adjust desktop, panel, and system preferences.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="272"/>
        <source>Tour</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="272"/>
        <source>Take a guided tour of MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="315"/>
        <source>Could not start the requested action.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="17"/>
        <location filename="../qml/Main.qml" line="103"/>
        <location filename="../qml/Main.qml" line="458"/>
        <source>MX Welcome</source>
        <translation>MX Приветствие</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="136"/>
        <source>Manual</source>
        <translation>Руководство</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="146"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="119"/>
        <source>Welcome</source>
        <translation>Добро пожаловать</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="119"/>
        <location filename="../qml/Main.qml" line="295"/>
        <source>About this system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="258"/>
        <source>No actions are available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="268"/>
        <source>Show this dialog at start up</source>
        <translation>Показывать это окно при запуске</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="312"/>
        <source>MX version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="313"/>
        <source>Debian version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="314"/>
        <source>Desktop</source>
        <translation>Рабочий стол</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="315"/>
        <source>Supported until</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="341"/>
        <source>Unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="355"/>
        <location filename="../qml/Main.qml" line="371"/>
        <source>Short system report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="366"/>
        <source>Loading system information…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="381"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Подробный отчёт Quick-System-Info</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="390"/>
        <location filename="../qml/Main.qml" line="399"/>
        <source>Terms of Use</source>
        <translation>Условия использования</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="425"/>
        <source>About MX Welcome</source>
        <translation>О программе MX Приветствие</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="466"/>
        <source>Version: %1</source>
        <translation>Версия: %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="472"/>
        <source>Program for displaying a welcome screen in MX Linux</source>
        <translation>Программа показа экрана приветствия в MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="479"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Авторское право (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="486"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="492"/>
        <source>MX Welcome License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="495"/>
        <location filename="../qml/Main.qml" line="501"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui_mainwindow.h" line="573"/>
        <source>MX Welcome</source>
        <translation>MX Приветствие</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="576"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="578"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="580"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="583"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="585"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="587"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="589"/>
        <source>Install MX Linux</source>
        <translation>Установить MX Linux</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="590"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Настройка (панели и пр.)</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="591"/>
        <source>Tools</source>
        <translation>Инструменты</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="592"/>
        <source>Wiki</source>
        <translation>Вики</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="593"/>
        <source>Users Manual</source>
        <translation>Руководство пользователя</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="594"/>
        <source>FAQ</source>
        <translation>ЧаВо</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="595"/>
        <source>Tour</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="596"/>
        <source>Popular Apps</source>
        <translation>Популярные приложения</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="597"/>
        <source>Contribute</source>
        <translation>Поддержать</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="598"/>
        <source>Videos</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="599"/>
        <source>Forums</source>
        <translation>Форумы</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="600"/>
        <source>Welcome</source>
        <translation>Добро пожаловать</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="601"/>
        <source>DESKTOP</source>
        <translation>РАБОЧИЙ СТОЛ</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="603"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Подробный отчёт Quick-System-Info</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="604"/>
        <source>Terms of Use</source>
        <translation>Условия использования</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="606"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>Название «MX Linux» подпадает под сублицензию Linux Foundation No. 20140605-0483. Мы разрабатываем программное обеспечение, на которое распространяется бесплатная лицензия, доступная в списке Вики. Мы также включаем программное обеспечение, разработанное другими, которое также имеет бесплатную лицензию.</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="607"/>
        <source>MX VERSION</source>
        <translation>ВЕРСИЯ MX</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="608"/>
        <source>DEBIAN VERSION:</source>
        <translation>ВЕРСИЯ DEBIAN:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="609"/>
        <source>SUPPORTED UNTIL:</source>
        <translation>СРОК ПОДДЕРЖКИ:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="611"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10.5pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="620"/>
        <source>SHORT SYSTEM REPORT:</source>
        <translation>КРАТКИЙ ОТЧЁТ О СИСТЕМЕ:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="621"/>
        <source>About</source>
        <translation>О</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="622"/>
        <source>Show this dialog at start up</source>
        <translation>Показывать этот диалог при запуске</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="74"/>
        <source>This tool displays the MX Linux welcome screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="78"/>
        <source>Start with About selected. The About page provides basic information about the current MX Linux version, the user&apos;s hardware, and access to a full system report.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="80"/>
        <source>Run a test mode.</source>
        <translation>Запустить тестовый режим.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="101"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>You must run this program as normal user.</source>
        <translation>Вы должны запускать эту программу как обычный пользователь.</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="69"/>
        <source>Open this tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
