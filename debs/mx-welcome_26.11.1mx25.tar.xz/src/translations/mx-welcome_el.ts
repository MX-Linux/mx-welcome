<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="el">
<context>
    <name>Backend</name>
    <message>
        <location filename="../src/backend.cpp" line="183"/>
        <location filename="../src/backend.cpp" line="208"/>
        <location filename="../src/backend.cpp" line="211"/>
        <location filename="../src/backend.cpp" line="234"/>
        <location filename="../src/backend.cpp" line="435"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="183"/>
        <source>Could not update the login startup setting.</source>
        <translation>Δεν ήταν δυνατή η ενημέρωση της ρύθμισης.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="211"/>
        <source>Could not open %1</source>
        <translation>Δεν κατέστη δυνατό το άνοιγμα του %1</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="222"/>
        <source>System information is unavailable.</source>
        <translation>Οι πληροφορίες του συστήματος δεν είναι διαθέσιμες.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="234"/>
        <source>Could not start Quick System Info.</source>
        <translation>Δεν ήταν δυνατή η εκκίνηση του Συνοπτικές πληροφορίες συστήματος.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="245"/>
        <source>Could not load the Terms of Use.</source>
        <translation>Δεν ήταν δυνατή η λήψη των όρων χρήσης.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="252"/>
        <source>Could not load %1</source>
        <translation>Δεν ήταν δυνατή η φόρτωση του %1</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Could not load changelog.</source>
        <translation>Δεν ήταν δυνατή η φόρτωση του αρχείου αλλαγών.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="311"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>Το όνομα &quot;MX Linux&quot; καλύπτεται από την υπο-άδεια χρήσης του Linux Foundation αρ. 20140605-0483. Αναπτύσσουμε λογισμικό που καλύπτεται από ελεύθερη άδεια και μπορεί να ελεγχθεί στη λίστα Wiki. Περιλαμβάνουμε επίσης λογισμικό που αναπτύχθηκε από άλλους και καλύπτεται από ελεύθερη άδεια χρήσης.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="322"/>
        <source>User demo, password: demo. Superuser root, password: root.</source>
        <translation>Χρήστης demo, κωδικός: demo. Διαχειριστής root, κωδικός: root.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="341"/>
        <source>%1 “%2”</source>
        <translation>%1 “%2”</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="358"/>
        <source>Install MX Linux</source>
        <translation>Εγκατάσταση του MX Linux</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="358"/>
        <source>Install MX Linux on this computer.</source>
        <translation>Εγκατάσταση του MX Linux στον υπολογιστή.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="359"/>
        <source>FAQ</source>
        <translation>Συχνές ερωτήσεις</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="359"/>
        <source>Find answers to frequently asked questions.</source>
        <translation>Δείτε απαντήσεις σε συχνές ερωτήσεις.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="360"/>
        <source>Forums</source>
        <translation>Φόρουμ</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="360"/>
        <source>Ask questions and join the MX Linux community.</source>
        <translation>Ρωτήστε και συμμετάσχετε στην κοινότητα του MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="361"/>
        <source>Users Manual</source>
        <translation>Εγχειρίδιο χρήστη MX Linux</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="361"/>
        <source>Read the documentation for your MX Linux release.</source>
        <translation>Διαβάστε την τεκμηρίωση της διανομής του MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="362"/>
        <source>Videos</source>
        <translation>Βίντεο</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="362"/>
        <source>Watch MX Linux tutorials and demonstrations.</source>
        <translation>Παρακολουθήστε εκπαιδευτικά βίντεο και επιδείξεις για το MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="363"/>
        <source>Wiki</source>
        <translation>Wiki</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="363"/>
        <source>Browse community-maintained guides and reference material.</source>
        <translation>Περιηγηθείτε σε οδηγίες και αναφορές που συντηρεί η κοινότητα.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="364"/>
        <source>Contribute</source>
        <translation>Συνεισφορά</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="364"/>
        <source>Learn how to support and contribute to MX Linux.</source>
        <translation>Δείτε πώς μπορείτε να υποστηρίξετε και να συνεισφέρετε στο MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="365"/>
        <source>Tools</source>
        <translation>Εργαλεία</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="365"/>
        <source>Open the collection of MX system utilities.</source>
        <translation>Ανοίξτε τη συλλογή βοηθητικών προγραμμάτων του συστήματος MX.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="366"/>
        <source>Popular Apps</source>
        <translation>Δημοφιλείς εφαρμογές</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="366"/>
        <source>Discover and install popular applications.</source>
        <translation>Ανακαλύψτε και εγκαταστήστε δημοφιλείς εφαρμογές.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="367"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Ρυθμίσεις (ταμπλό, κλπ...)</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="367"/>
        <source>Adjust desktop, panel, and system preferences.</source>
        <translation>Προσαρμόστε την επιφάνεια εργασίας, το ταμπλό και τις ρυθμίσεις του συστήματος.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="368"/>
        <source>Tour</source>
        <translation>Περιήγηση</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="368"/>
        <source>Take a guided tour of MX Linux.</source>
        <translation>Κάνετε ξενάγηση στο MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="208"/>
        <location filename="../src/backend.cpp" line="435"/>
        <source>Could not start the requested action.</source>
        <translation>Δεν ήταν δυνατή η εκκίνηση της ενέργειας.</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="14"/>
        <location filename="../qml/Main.qml" line="90"/>
        <location filename="../qml/Main.qml" line="451"/>
        <source>MX Welcome</source>
        <translation>MX Οθόνη υποδοχής</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="123"/>
        <source>Manual</source>
        <translation>Εγχειρίδιο</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="133"/>
        <source>About</source>
        <translation>Περί</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="106"/>
        <source>Welcome</source>
        <translation>Καλώς ήρθατε</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="106"/>
        <location filename="../qml/Main.qml" line="288"/>
        <source>About this system</source>
        <translation>Σχετικά με αυτό το σύστημα</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="248"/>
        <source>No actions are available.</source>
        <translation>Δεν υπάρχουν διαθέσιμες ενέργειες.</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="258"/>
        <source>Show this dialog at start up</source>
        <translation>Εμφάνιση αυτού του παραθύρου στην εκκίνηση</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="305"/>
        <source>MX version</source>
        <translation>Έκδοση MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="306"/>
        <source>Debian version</source>
        <translation>Έκδοση Debian</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="307"/>
        <source>Desktop</source>
        <translation>Επιφάνεια εργασίας</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="308"/>
        <source>Supported until</source>
        <translation>Υποστηρίζεται έως</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="334"/>
        <source>Unavailable</source>
        <translation>Μη διαθέσιμο</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="348"/>
        <location filename="../qml/Main.qml" line="364"/>
        <source>Short system report</source>
        <translation>Σύντομη αναφορά συστήματος</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="359"/>
        <source>Loading system information…</source>
        <translation>Λήψη πληροφοριών συστήματος…</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="374"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Πλήρης αναφορά του - Συνοπτικές πληροφορίες συστήματος</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="383"/>
        <location filename="../qml/Main.qml" line="392"/>
        <source>Terms of Use</source>
        <translation>Όροι χρήσης</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="418"/>
        <source>About MX Welcome</source>
        <translation>Περί του MX Οθόνη υποδοχής</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="459"/>
        <source>Version: %1</source>
        <translation>Έκδοση: %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="465"/>
        <source>Program for displaying a welcome screen in MX Linux</source>
        <translation>Πρόγραμμα για την εμφάνιση της οθόνης υποδοχής του MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="472"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Πνευματικά δικαιώματα (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="479"/>
        <source>License</source>
        <translation>Άδεια</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="485"/>
        <source>MX Welcome License</source>
        <translation>Άδεια του MX Οθόνη υποδοχής</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="488"/>
        <location filename="../qml/Main.qml" line="494"/>
        <source>Changelog</source>
        <translation>Αρχείο αλλαγών</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui_mainwindow.h" line="573"/>
        <source>MX Welcome</source>
        <translation>MX Οθόνη υποδοχής</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="576"/>
        <source>Quit application</source>
        <translation>Κλείσιμο εφαρμογής</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="578"/>
        <source>Close</source>
        <translation>Κλείσιμο</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="580"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="583"/>
        <source>About this application</source>
        <translation>Περί της εφαρμογής</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="585"/>
        <source>About...</source>
        <translation>Περί...</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="587"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="589"/>
        <source>Install MX Linux</source>
        <translation>Εγκατάσταση του MX Linux</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="590"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Ρυθμίσεις (ταμπλό, κλπ...)</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="591"/>
        <source>Tools</source>
        <translation>Εργαλεία</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="592"/>
        <source>Wiki</source>
        <translation>Wiki</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="593"/>
        <source>Users Manual</source>
        <translation>Εγχειρίδιο χρήστη MX Linux</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="594"/>
        <source>FAQ</source>
        <translation>Συχνές ερωτήσεις</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="595"/>
        <source>Tour</source>
        <translation>Περιήγηση</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="596"/>
        <source>Popular Apps</source>
        <translation>Δημοφιλείς εφαρμογές</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="597"/>
        <source>Contribute</source>
        <translation>Συνεισφορά</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="598"/>
        <source>Videos</source>
        <translation>Βίντεο</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="599"/>
        <source>Forums</source>
        <translation>Φόρουμ</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="600"/>
        <source>Welcome</source>
        <translation>Καλώς ήρθατε</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="601"/>
        <source>DESKTOP</source>
        <translation>ΕΠΙΦΑΝΕΙΑ ΕΡΓΑΣΙΑΣ</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="603"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Πλήρης αναφορά του - Συνοπτικές πληροφορίες συστήματος</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="604"/>
        <source>Terms of Use</source>
        <translation>Όροι χρήσης</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="606"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>Το όνομα &quot;MX Linux&quot; καλύπτεται από την υπο-άδεια χρήσης του Linux Foundation αρ. 20140605-0483. Αναπτύσσουμε λογισμικό που καλύπτεται από ελεύθερη άδεια και μπορεί να ελεγχθεί στη λίστα Wiki. Περιλαμβάνουμε επίσης λογισμικό που αναπτύχθηκε από άλλους και καλύπτεται από ελεύθερη άδεια χρήσης.</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="607"/>
        <source>MX VERSION</source>
        <translation>ΕΚΔΟΣΗ MX</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="608"/>
        <source>DEBIAN VERSION:</source>
        <translation>ΕΚΔΟΣΗ DEBIAN:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="609"/>
        <source>SUPPORTED UNTIL:</source>
        <translation>ΥΠΟΣΤΗΡΙΖΕΤΑΙ ΜΕΧΡΙ:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="611"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10.5pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="620"/>
        <source>SHORT SYSTEM REPORT:</source>
        <translation>ΣΥΝΤΟΜΗ ΑΝΑΦΟΡΑ ΣΥΣΤΗΜΑΤΟΣ:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="621"/>
        <source>About</source>
        <translation>Περί</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="622"/>
        <source>Show this dialog at start up</source>
        <translation>Εμφάνιση αυτού του παραθύρου στην εκκίνηση</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="97"/>
        <source>This tool displays the MX Linux welcome screen.</source>
        <translation>Αυτό το εργαλείο εμφανίζει την οθόνη υποδοχής του MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="101"/>
        <source>Start with About selected. The About page provides basic information about the current MX Linux version, the user&apos;s hardware, and access to a full system report.</source>
        <translation>Εκκίνηση με την επιλογή Περί. Αυτή η σελίδα παρέχει βασικές πληροφορίες για τη τρέχουσα έκδοση του MX Linux, το υλικό καθώς και μια πλήρη αναφορά του συστήματος.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>Run a test mode.</source>
        <translation>Δοκιμή.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="111"/>
        <source>Error</source>
        <translation>Σφάλμα</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="112"/>
        <source>You must run this program as normal user.</source>
        <translation>Πρέπει να τρέξετε αυτή την εφαρμογή ως απλός χρήστης.</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="69"/>
        <source>Open this tool</source>
        <translation>Άνοιγμα του εργαλείου</translation>
    </message>
</context>
</TS>
