<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>Backend</name>
    <message>
        <location filename="../src/backend.cpp" line="183"/>
        <location filename="../src/backend.cpp" line="208"/>
        <location filename="../src/backend.cpp" line="211"/>
        <location filename="../src/backend.cpp" line="234"/>
        <location filename="../src/backend.cpp" line="435"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="183"/>
        <source>Could not update the login startup setting.</source>
        <translation>No se pudo actualizar la configuración de inicio de sesión.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="211"/>
        <source>Could not open %1</source>
        <translation>No se pudo abrir %1</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="222"/>
        <source>System information is unavailable.</source>
        <translation>No hay información del sistema disponible.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="234"/>
        <source>Could not start Quick System Info.</source>
        <translation>No se pudo iniciar Información rápida del sistema.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="245"/>
        <source>Could not load the Terms of Use.</source>
        <translation>No se pudieron cargar las condiciones de uso.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="252"/>
        <source>Could not load %1</source>
        <translation>No se pudo cargar %1</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Could not load changelog.</source>
        <translation>No se pudo cargar el registro de cambios.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="311"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>El nombre “MX Linux” está cubierto por la Sublicencia de Linux Foundation No. 20140605-0483. Desarrollamos software que está cubierto por una licencia gratuita que se puede examinar en la lista Wiki. También incluimos software desarrollado por otros que está bajo una licencia gratuita.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="322"/>
        <source>User demo, password: demo. Superuser root, password: root.</source>
        <translation>Usuario demo, contraseña: demo. Superusuario root, contraseña: root.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="341"/>
        <source>%1 “%2”</source>
        <translation>%1 “%2”</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="358"/>
        <source>Install MX Linux</source>
        <translation>Instalar MX Linux</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="358"/>
        <source>Install MX Linux on this computer.</source>
        <translation>Instalar MX Linux en este ordenador.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="359"/>
        <source>FAQ</source>
        <translation>FAQ (Preguntas frecuentes)</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="359"/>
        <source>Find answers to frequently asked questions.</source>
        <translation>Encuentre respuestas a las preguntas más frecuentes.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="360"/>
        <source>Forums</source>
        <translation>Foros</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="360"/>
        <source>Ask questions and join the MX Linux community.</source>
        <translation>Haga preguntas y únase a la comunidad de MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="361"/>
        <source>Users Manual</source>
        <translation>Manual del Usuario</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="361"/>
        <source>Read the documentation for your MX Linux release.</source>
        <translation>Lea la documentación correspondiente a su versión de MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="362"/>
        <source>Videos</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="362"/>
        <source>Watch MX Linux tutorials and demonstrations.</source>
        <translation>Vea tutoriales y presentaciones de MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="363"/>
        <source>Wiki</source>
        <translation>Wiki</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="363"/>
        <source>Browse community-maintained guides and reference material.</source>
        <translation>Explore las guías y el material de referencia que mantiene la comunidad.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="364"/>
        <source>Contribute</source>
        <translation>Contribuir</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="364"/>
        <source>Learn how to support and contribute to MX Linux.</source>
        <translation>Descubra cómo apoyar y colaborar con MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="365"/>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="365"/>
        <source>Open the collection of MX system utilities.</source>
        <translation>Abrir la colección de utilidades del sistema MX.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="366"/>
        <source>Popular Apps</source>
        <translation>Apps Populares</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="366"/>
        <source>Discover and install popular applications.</source>
        <translation>Descubra e instale aplicaciones populares.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="367"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Retocar (Panel, etc...)</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="367"/>
        <source>Adjust desktop, panel, and system preferences.</source>
        <translation>Ajuste las preferencias del escritorio, del panel y del sistema.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="368"/>
        <source>Tour</source>
        <translation>Paseo</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="368"/>
        <source>Take a guided tour of MX Linux.</source>
        <translation>Haga una visita guiada por MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="208"/>
        <location filename="../src/backend.cpp" line="435"/>
        <source>Could not start the requested action.</source>
        <translation>No se pudo iniciar la acción solicitada.</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="14"/>
        <location filename="../qml/Main.qml" line="90"/>
        <location filename="../qml/Main.qml" line="451"/>
        <source>MX Welcome</source>
        <translation>MX Bienvenida</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="123"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="133"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="106"/>
        <source>Welcome</source>
        <translation>¡Bienvenido!</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="106"/>
        <location filename="../qml/Main.qml" line="288"/>
        <source>About this system</source>
        <translation>Acerca de este sistema</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="248"/>
        <source>No actions are available.</source>
        <translation>No hay acciones disponibles.</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="258"/>
        <source>Show this dialog at start up</source>
        <translation>Mostrar esta ventana al inicio</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="305"/>
        <source>MX version</source>
        <translation>Versión de MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="306"/>
        <source>Debian version</source>
        <translation>Versión de Debian</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="307"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="308"/>
        <source>Supported until</source>
        <translation>Compatible hasta </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="334"/>
        <source>Unavailable</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="348"/>
        <location filename="../qml/Main.qml" line="364"/>
        <source>Short system report</source>
        <translation>Breve informe sobre el sistema</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="359"/>
        <source>Loading system information…</source>
        <translation>Cargando la información del sistema…</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="374"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Informe rápido del sistema (QSI) Reporte Completo</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="383"/>
        <location filename="../qml/Main.qml" line="392"/>
        <source>Terms of Use</source>
        <translation>Condiciones de uso</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="418"/>
        <source>About MX Welcome</source>
        <translation>Acerca de MX Bienvenida</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="459"/>
        <source>Version: %1</source>
        <translation>Versión: %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="465"/>
        <source>Program for displaying a welcome screen in MX Linux</source>
        <translation>Programa para desplegar una pantalla de bienvenida en MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="472"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Derechos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="479"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="485"/>
        <source>MX Welcome License</source>
        <translation>Licencia de Bienvenido a MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="488"/>
        <location filename="../qml/Main.qml" line="494"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui_mainwindow.h" line="573"/>
        <source>MX Welcome</source>
        <translation>MX Bienvenida</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="576"/>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="578"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="580"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="583"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="585"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="587"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="589"/>
        <source>Install MX Linux</source>
        <translation>Instalar MX Linux</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="590"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Retocar (Panel, etc...)</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="591"/>
        <source>Tools</source>
        <translation>Herramientas</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="592"/>
        <source>Wiki</source>
        <translation>Wiki</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="593"/>
        <source>Users Manual</source>
        <translation>Manual del Usuario</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="594"/>
        <source>FAQ</source>
        <translation>FAQ (Preguntas frecuentes)</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="595"/>
        <source>Tour</source>
        <translation>Paseo</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="596"/>
        <source>Popular Apps</source>
        <translation>Apps Populares</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="597"/>
        <source>Contribute</source>
        <translation>Contribuir</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="598"/>
        <source>Videos</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="599"/>
        <source>Forums</source>
        <translation>Foros</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="600"/>
        <source>Welcome</source>
        <translation>¡Bienvenido!</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="601"/>
        <source>DESKTOP</source>
        <translation>ESCRITORIO</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="603"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Informe rápido del sistema (QSI) Reporte Completo</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="604"/>
        <source>Terms of Use</source>
        <translation>Condiciones de uso</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="606"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>El nombre “MX Linux” está cubierto por la Sublicencia de Linux Foundation No. 20140605-0483. Desarrollamos software que está cubierto por una licencia gratuita que se puede examinar en la lista Wiki. También incluimos software desarrollado por otros que está bajo una licencia gratuita.</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="607"/>
        <source>MX VERSION</source>
        <translation>VERSIÓN MX</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="608"/>
        <source>DEBIAN VERSION:</source>
        <translation>VERSIÓN DEBIAN:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="609"/>
        <source>SUPPORTED UNTIL:</source>
        <translation>CON SOPORTE HASTA:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="611"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10.5pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10.5pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="620"/>
        <source>SHORT SYSTEM REPORT:</source>
        <translation>REPORTE CORTO DEL SISTEMA:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="621"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="622"/>
        <source>Show this dialog at start up</source>
        <translation>Mostrar esta ventana al inicio</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="97"/>
        <source>This tool displays the MX Linux welcome screen.</source>
        <translation>Esta herramienta muestra la pantalla de bienvenida de MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="101"/>
        <source>Start with About selected. The About page provides basic information about the current MX Linux version, the user&apos;s hardware, and access to a full system report.</source>
        <translation>Empiece por seleccionar &quot;Acerca de&quot;. La página &quot;Acerca de&quot; ofrece información básica sobre la versión actual de MX Linux, el hardware del usuario y acceso a un informe completo del sistema.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="103"/>
        <source>Run a test mode.</source>
        <translation>Ejecutar un modo de prueba.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="111"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="112"/>
        <source>You must run this program as normal user.</source>
        <translation>Debe ejecutar este programa como un usuario normal.</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="69"/>
        <source>Open this tool</source>
        <translation>Abre esta herramienta</translation>
    </message>
</context>
</TS>
