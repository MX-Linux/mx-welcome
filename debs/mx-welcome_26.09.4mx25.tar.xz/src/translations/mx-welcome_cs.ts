<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs">
<context>
    <name>Backend</name>
    <message>
        <location filename="../src/backend.cpp" line="74"/>
        <location filename="../src/backend.cpp" line="95"/>
        <location filename="../src/backend.cpp" line="118"/>
        <location filename="../src/backend.cpp" line="315"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="74"/>
        <source>Could not update the login startup setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="95"/>
        <source>Could not open %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="106"/>
        <source>System information is unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="118"/>
        <source>Could not start Quick System Info.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="129"/>
        <source>Could not load the Terms of Use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="136"/>
        <source>Could not load %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="146"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="197"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>Název “MX Linux” je chráněný Linux Foundation Sublicense No. 20140605-0483. Jde o námi vyvinutý software, který je licencovaný, volně dostupný. Licenci je možné shlédnout ve Wiki seznamu. V systému je  zahrnut i software vyvinut jinými stranami, který je taktéž licencován jako volně dostupný.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="208"/>
        <source>User demo, password: demo. Superuser root, password: root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="228"/>
        <source>%1 “%2”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Install MX Linux</source>
        <translation>Nainstalovat MX Linux</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Install MX Linux on this computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="263"/>
        <source>FAQ</source>
        <translation>FAQ (často kladené otázky)</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="263"/>
        <source>Find answers to frequently asked questions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="264"/>
        <source>Forums</source>
        <translation>Fórum</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="264"/>
        <source>Ask questions and join the MX Linux community.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="265"/>
        <source>Users Manual</source>
        <translation>Uživatelská příručka</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="265"/>
        <source>Read the documentation for your MX Linux release.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="266"/>
        <source>Videos</source>
        <translation>Videa</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="266"/>
        <source>Watch MX Linux tutorials and demonstrations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="267"/>
        <source>Wiki</source>
        <translation>Wiki</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="267"/>
        <source>Browse community-maintained guides and reference material.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="268"/>
        <source>Contribute</source>
        <translation>Přispějte</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="268"/>
        <source>Learn how to support and contribute to MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="269"/>
        <source>Tools</source>
        <translation>Nástroje</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="269"/>
        <source>Open the collection of MX system utilities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="270"/>
        <source>Popular Apps</source>
        <translation>Populární aplikace</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="270"/>
        <source>Discover and install popular applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="271"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Vyladění (Panel, atd...)</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="271"/>
        <source>Adjust desktop, panel, and system preferences.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="272"/>
        <source>Tour</source>
        <translation>Tour</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="272"/>
        <source>Take a guided tour of MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="315"/>
        <source>Could not start the requested action.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="17"/>
        <location filename="../qml/Main.qml" line="103"/>
        <location filename="../qml/Main.qml" line="456"/>
        <source>MX Welcome</source>
        <translation>MX Vítejte</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="136"/>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="146"/>
        <source>About</source>
        <translation>O aplikaci</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="119"/>
        <source>Welcome</source>
        <translation>Vítejte</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="119"/>
        <location filename="../qml/Main.qml" line="293"/>
        <source>About this system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="258"/>
        <source>No actions are available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="268"/>
        <source>Show this dialog at start up</source>
        <translation>Zobraz tento dialog při startu</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="310"/>
        <source>MX version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="311"/>
        <source>Debian version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="312"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="313"/>
        <source>Supported until</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="339"/>
        <source>Unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="353"/>
        <location filename="../qml/Main.qml" line="369"/>
        <source>Short system report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="364"/>
        <source>Loading system information…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="379"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Rychlé-Info-o-Systému Plný Záznam</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="388"/>
        <location filename="../qml/Main.qml" line="397"/>
        <source>Terms of Use</source>
        <translation>Podmínky použití</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="423"/>
        <source>About MX Welcome</source>
        <translation>O MX Vítejte</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="464"/>
        <source>Version: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="470"/>
        <source>Program for displaying a welcome screen in MX Linux</source>
        <translation>Program pro zobrazení uvítací obrazovky MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="477"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Vlastnická práva (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="484"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="490"/>
        <source>MX Welcome License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="493"/>
        <location filename="../qml/Main.qml" line="499"/>
        <source>Changelog</source>
        <translation>Protokol změn</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui_mainwindow.h" line="573"/>
        <source>MX Welcome</source>
        <translation>MX Vítejte</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="576"/>
        <source>Quit application</source>
        <translation>Ukončit aplikaci</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="578"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="580"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="583"/>
        <source>About this application</source>
        <translation>O této aplikaci</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="585"/>
        <source>About...</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="587"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="600"/>
        <source>Welcome</source>
        <translation>Vítejte</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="589"/>
        <source>Install MX Linux</source>
        <translation>Nainstalovat MX Linux</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="590"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Vyladění (Panel, atd...)</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="591"/>
        <source>Tools</source>
        <translation>Nástroje</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="592"/>
        <source>Wiki</source>
        <translation>Wiki</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="593"/>
        <source>Users Manual</source>
        <translation>Uživatelská příručka</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="594"/>
        <source>FAQ</source>
        <translation>FAQ (často kladené otázky)</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="595"/>
        <source>Tour</source>
        <translation>Tour</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="596"/>
        <source>Popular Apps</source>
        <translation>Populární aplikace</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="597"/>
        <source>Contribute</source>
        <translation>Přispějte</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="598"/>
        <source>Videos</source>
        <translation>Videa</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="599"/>
        <source>Forums</source>
        <translation>Fórum</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="611"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10.5pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="621"/>
        <source>About</source>
        <translation>O aplikaci</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="620"/>
        <source>SHORT SYSTEM REPORT:</source>
        <translation>KRÁTKÝ SYSTÉMOVÝ REPORT:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="601"/>
        <source>DESKTOP</source>
        <translation>DESKTOP</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="603"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Rychlé-Info-o-Systému Plný Záznam</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="604"/>
        <source>Terms of Use</source>
        <translation>Podmínky použití</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="606"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>Název “MX Linux” je chráněný Linux Foundation Sublicense No. 20140605-0483. Jde o námi vyvinutý software, který je licencovaný, volně dostupný. Licenci je možné shlédnout ve Wiki seznamu. V systému je  zahrnut i software vyvinut jinými stranami, který je taktéž licencován jako volně dostupný.</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="607"/>
        <source>MX VERSION</source>
        <translation>VERZE MX</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="608"/>
        <source>DEBIAN VERSION:</source>
        <translation>VERZE DEBIANU:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="609"/>
        <source>SUPPORTED UNTIL:</source>
        <translation>PODPORA KONČÍ:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="622"/>
        <source>Show this dialog at start up</source>
        <translation>Zobraz tento dialog při startu</translation>
    </message>
    <message>
        <source>User demo, password:</source>
        <translation type="vanished">Uživatel demo, heslo:</translation>
    </message>
    <message>
        <source>Superuser root, password:</source>
        <translation type="vanished">Superuživatel root, heslo:</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">Chyba</translation>
    </message>
    <message>
        <source>About MX Welcome</source>
        <translation type="vanished">O MX Vítejte</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="vanished">Verze:</translation>
    </message>
    <message>
        <source>Program for displaying a welcome screen in MX Linux</source>
        <translation type="vanished">Program pro zobrazení uvítací obrazovky MX Linux</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">Vlastnická práva (c) MX Linux</translation>
    </message>
    <message>
        <source>License</source>
        <translation type="vanished">Licence</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">Protokol změn</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Zrušit</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;Zavřít</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>You must run this program as normal user.</source>
        <translation type="vanished">Tento program musíte spustit jako normální uživatel</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>This tool displays a welcome screen with two tabs.</source>
        <translation type="vanished">Tento program zobrazuje uvítací obrazovku ve dvou záložkách.</translation>
    </message>
    <message>
        <source>Start with About tab selected. The About tab provides basic information about the current MX Linux version, the user&apos;s hardware, and access to a full system report.</source>
        <translation type="vanished">Vybrán Start na záložce O programu. Tato záložka poskytuje základní informaci o aktuální verzi MX Linux, informaci o hardvéru a taky přistup k úplnému systémovému reportu.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="67"/>
        <source>This tool displays the MX Linux welcome screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="71"/>
        <source>Start with About selected. The About page provides basic information about the current MX Linux version, the user&apos;s hardware, and access to a full system report.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="73"/>
        <source>Run a test mode.</source>
        <translation>Spustit testovací mód.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="95"/>
        <source>You must run this program as normal user.</source>
        <translation>Tento program musíte spustit jako normální uživatel</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="67"/>
        <source>Open this tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
