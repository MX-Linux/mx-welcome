# AGENTS.md

## Project overview

MX Welcome is a C++20/Qt 6 application with a Qt Quick/QML user interface. It
shows the MX Linux welcome dashboard, exposes system information, manages the
per-user autostart preference, and launches configured MX tools and web links.

The current application is not the former Qt Widgets `MainWindow` UI. Do not
reintroduce or refer to the removed `MainWindow`, `About`, `FlatButton`, `.ui`,
or qmake architecture.

## Source map and ownership

- `src/main.cpp` creates the application, parses command-line options, installs
  translations and the theme-icon provider, exposes `Backend` to QML, and loads
  the `MxWelcome` QML module.
- `src/backend.{h,cpp}` owns configuration lookup, MX/system integration,
  persistence, filtering of available actions, system-information collection,
  and external process/URL launching.
- `src/actionmodel.{h,cpp}` is the `QAbstractListModel` boundary used by the QML
  action grid. Keep its role names synchronized with required delegate
  properties in `qml/Main.qml`.
- `qml/Main.qml` owns the application window, navigation, responsive layouts,
  dialogs, and bindings to `Backend`.
- `qml/components/ToolCard.qml` and `SecondaryButton.qml` are reusable visual
  controls. Prefer extending these over duplicating styles in `Main.qml`.
- `CMakeLists.txt` defines the executable, embedded QML module/resources,
  translations, warnings, and installation target.
- `debian/` contains the production package metadata and install layout.

Keep presentation and interaction state in QML. Put filesystem access,
settings, command execution, system probing, and other platform behavior in
the C++ backend. Expose new backend data with `Q_PROPERTY` and a suitable
change signal, and expose user-triggered operations with `Q_INVOKABLE` or
slots.

## Important design constraints

- Keep `QApplication` and the Qt Widgets dependency even though the frontend is
  QML. MX/XFCE relies on Qt's GTK integration to provide the desktop palette,
  fonts, and icon behavior to Qt Quick.
- Do not force a Qt Quick Controls style or hard-code a light/dark theme. Use
  `SystemPalette` and the palette-derived colors already defined in
  `qml/Main.qml`.
- Preserve support for the older Qt 6 releases used by supported MX/Debian
  systems. Qt policies and QML resource/module loading are version-gated in
  `CMakeLists.txt` and `src/main.cpp`; do not replace these paths with APIs that
  require Qt 6.5+ without deliberately changing the supported baseline.
- QML and the bundled SVG are embedded by `qt6_add_qml_module`. If QML files or
  resources are added or renamed, update its `QML_FILES` or `RESOURCES` list.
- Configuration is read first from `/etc/mx-welcome/mx-welcome.conf`, then from
  `/usr/share/mx-welcome/mx-welcome.conf`, with built-in fallbacks. Preserve
  that override order and the visibility rules for live-session actions.
- User settings use the organization/application names set in `main.cpp`.
  Autostart also creates or removes
  `~/.config/autostart/mx-welcome.desktop`; keep the setting and file state in
  sync and report failures through `Backend::errorOccurred`.
- Treat configured commands as trusted system configuration, but do not route
  new data derived from users or untrusted sources through `/bin/sh -c`.
- The application must refuse to run as root.

## Build and verification

Install Qt 6 Core, Gui, Widgets, Qml, Quick, QuickControls2, LinguistTools, and
the Qt Declarative development files, plus CMake, Ninja, and a C++20 compiler.

Preferred local commands:

```bash
./build.sh                 # Release build in build/
./build.sh --debug         # Debug build
./build.sh --clean         # Clean release rebuild
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
```

The project enables strict warnings and `-Werror`, so a successful build is a
required check for C++ and CMake changes. CI builds Release configurations with
both GCC and Clang and also performs an unsigned binary Debian package build.
For packaging changes, use:

```bash
debuild -us -uc -b
```

There is currently no automated test target (`debian/rules` explicitly skips
tests). For UI or integration changes, build and smoke-test the executable as a
normal user. `build/mx-welcome --test` exposes live-session-only content for
inspection; `--about` starts on the system page. Exercise keyboard focus,
scrolling, dialogs, both narrow and wide layouts, and light/dark desktop
palettes as relevant to the change.

Do not commit generated or local build artifacts such as `build/`, `obj-*`,
`*.qm`, Qt Creator files, Debian build products, or files under `debs/` unless
the task specifically updates packaged release artifacts.

## Code and QML conventions

- Follow the existing C++20/Qt style: four-space indentation, braces on their
  own line, `QStringLiteral` for fixed strings, `QLatin1String`/`QLatin1Char`
  for comparisons and separators, `m_` member prefixes, and `[[nodiscard]]`
  on value-returning accessors where appropriate.
- Use `#pragma once` in headers and keep classes narrowly scoped. Avoid adding
  synchronous process work to QML.
- Follow the existing QML style: four-space indentation, typed/`required`
  properties for component contracts, layouts instead of fixed positioning,
  palette-derived colors, and accessible names/roles for interactive controls.
- Keep action identifiers stable because QML and configuration dispatch by
  identifier. When adding a model role, update the enum, `data()`,
  `roleNames()`, and the QML delegate together.
- Preserve translations. Use `tr()` for C++ user-visible strings and `qsTr()`
  for QML user-visible strings. Translation catalogs live in `translations/`;
  desktop-file translations are maintained separately under
  `translations-desktop-file/`.
- Versions come from `debian/changelog` via `dpkg-parsechangelog`; do not edit a
  generated version header or duplicate the version in source code.

## Change checklist

Before handing off a change:

1. Build the affected configuration successfully.
2. If the C++/QML interface changed, verify every property, signal, invokable,
   model role, and required delegate property on both sides.
3. If UI behavior changed, perform a normal-user smoke test and check keyboard
   accessibility and responsive sizing.
4. If files, runtime modules, or install paths changed, update both CMake and
   Debian packaging metadata.
5. Review user-visible strings for translation coverage and avoid unrelated
   edits to translation catalogs or generated artifacts.
