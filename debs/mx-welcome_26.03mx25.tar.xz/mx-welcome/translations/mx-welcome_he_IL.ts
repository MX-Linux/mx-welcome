<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="he_IL">
<context>
    <name>Backend</name>
    <message>
        <location filename="../src/backend.cpp" line="74"/>
        <location filename="../src/backend.cpp" line="95"/>
        <location filename="../src/backend.cpp" line="118"/>
        <location filename="../src/backend.cpp" line="314"/>
        <source>Error</source>
        <translation type="unfinished">שגיאה</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="74"/>
        <source>Could not update the login startup setting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="95"/>
        <source>Could not open %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="106"/>
        <source>System information is unavailable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="118"/>
        <source>Could not start Quick System Info.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="129"/>
        <source>Could not load the Terms of Use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="136"/>
        <source>Could not load %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="146"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="197"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="208"/>
        <source>User demo, password: demo. Superuser root, password: root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="228"/>
        <source>%1 “%2”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Install MX Linux</source>
        <translation type="unfinished">התקנת לינוקס MX</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Install MX Linux on this computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="263"/>
        <source>FAQ</source>
        <translation type="unfinished">שו״ת</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="263"/>
        <source>Find answers to frequently asked questions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="264"/>
        <source>Forums</source>
        <translation type="unfinished">פורומים</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="264"/>
        <source>Ask questions and join the MX Linux community.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="265"/>
        <source>Users Manual</source>
        <translation type="unfinished">מדריך למשתמשים</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="265"/>
        <source>Read the documentation for your MX Linux release.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="266"/>
        <source>Videos</source>
        <translation type="unfinished">סרטונים</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="266"/>
        <source>Watch MX Linux tutorials and demonstrations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="267"/>
        <source>Wiki</source>
        <translation type="unfinished">ויקי</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="267"/>
        <source>Browse community-maintained guides and reference material.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="268"/>
        <source>Contribute</source>
        <translation type="unfinished">תרומה</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="268"/>
        <source>Learn how to support and contribute to MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="269"/>
        <source>Tools</source>
        <translation type="unfinished">כלים</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="269"/>
        <source>Open the collection of MX system utilities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="270"/>
        <source>Popular Apps</source>
        <translation type="unfinished">יישומים נפוצים</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="270"/>
        <source>Discover and install popular applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="271"/>
        <source>Tweak (Panel, etc...)</source>
        <translation type="unfinished">התאמות (לוח, ועוד…)</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="271"/>
        <source>Adjust desktop, panel, and system preferences.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="272"/>
        <source>Tour</source>
        <translation type="unfinished">סיור</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="272"/>
        <source>Take a guided tour of MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="314"/>
        <source>Could not start the requested action.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="19"/>
        <location filename="../qml/Main.qml" line="105"/>
        <location filename="../qml/Main.qml" line="451"/>
        <source>MX Welcome</source>
        <translation type="unfinished">תכנית קבלת הפנים של MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="138"/>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="148"/>
        <source>About</source>
        <translation type="unfinished">על אודות</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="121"/>
        <source>Welcome</source>
        <translation type="unfinished">ברוך בואך</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="121"/>
        <location filename="../qml/Main.qml" line="294"/>
        <source>About this system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="260"/>
        <source>No actions are available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="270"/>
        <source>Show this dialog at start up</source>
        <translation type="unfinished">הצגת החלונית הזאת בפתיחה</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="311"/>
        <source>MX version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="312"/>
        <source>Debian version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="313"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="314"/>
        <source>Supported until</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="340"/>
        <source>Unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="354"/>
        <location filename="../qml/Main.qml" line="369"/>
        <source>Short system report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="365"/>
        <source>Loading system information…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="379"/>
        <source>Quick-System-Info Full Report</source>
        <translation type="unfinished">דוח מלא מידע מערכת מלא</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="388"/>
        <location filename="../qml/Main.qml" line="397"/>
        <source>Terms of Use</source>
        <translation type="unfinished">תנאי שימוש</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="423"/>
        <source>About MX Welcome</source>
        <translation type="unfinished">על תכנית קבלת הפנים של MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="459"/>
        <source>Version: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="465"/>
        <source>Program for displaying a welcome screen in MX Linux</source>
        <translation type="unfinished">תכנית להצגת מסך קבלת פנים ב־MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="472"/>
        <source>Copyright (c) MX Linux</source>
        <translation type="unfinished">זכויות היוצרים (c) שמורות ל־MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="479"/>
        <source>License</source>
        <translation type="unfinished">רשיון</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="485"/>
        <source>MX Welcome License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="488"/>
        <location filename="../qml/Main.qml" line="494"/>
        <source>Changelog</source>
        <translation type="unfinished">יומן שינויים</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MX Welcome</source>
        <translation type="vanished">תכנית קבלת הפנים של MX</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="vanished">יציאה מהתוכנה</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">סגירה</translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="vanished">Alt+N</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">על יישום זה</translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="vanished">על אודות…</translation>
    </message>
    <message>
        <source>Alt+B</source>
        <translation type="vanished">Alt+B</translation>
    </message>
    <message>
        <source>Welcome</source>
        <translation type="vanished">ברוך בואך</translation>
    </message>
    <message>
        <source>Install MX Linux</source>
        <translation type="vanished">התקנת לינוקס MX</translation>
    </message>
    <message>
        <source>Tweak (Panel, etc...)</source>
        <translation type="vanished">התאמות (לוח, ועוד…)</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation type="vanished">כלים</translation>
    </message>
    <message>
        <source>Wiki</source>
        <translation type="vanished">ויקי</translation>
    </message>
    <message>
        <source>Users Manual</source>
        <translation type="vanished">מדריך למשתמשים</translation>
    </message>
    <message>
        <source>FAQ</source>
        <translation type="vanished">שו״ת</translation>
    </message>
    <message>
        <source>Tour</source>
        <translation type="vanished">סיור</translation>
    </message>
    <message>
        <source>Popular Apps</source>
        <translation type="vanished">יישומים נפוצים</translation>
    </message>
    <message>
        <source>Contribute</source>
        <translation type="vanished">תרומה</translation>
    </message>
    <message>
        <source>Videos</source>
        <translation type="vanished">סרטונים</translation>
    </message>
    <message>
        <source>Forums</source>
        <translation type="vanished">פורומים</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="vanished">על אודות</translation>
    </message>
    <message>
        <source>SHORT SYSTEM REPORT:</source>
        <translation type="vanished">דוח מערכת קצר:</translation>
    </message>
    <message>
        <source>DESKTOP</source>
        <translation type="vanished">שולחן עבודה</translation>
    </message>
    <message>
        <source>Quick-System-Info Full Report</source>
        <translation type="vanished">דוח מלא מידע מערכת מלא</translation>
    </message>
    <message>
        <source>Terms of Use</source>
        <translation type="vanished">תנאי שימוש</translation>
    </message>
    <message>
        <source>MX VERSION</source>
        <translation type="vanished">גרסת MX</translation>
    </message>
    <message>
        <source>DEBIAN VERSION:</source>
        <translation type="vanished">גרסת דביאן:</translation>
    </message>
    <message>
        <source>SUPPORTED UNTIL:</source>
        <translation type="vanished">תמיכה עד:</translation>
    </message>
    <message>
        <source>Show this dialog at start up</source>
        <translation type="vanished">הצגת החלונית הזאת בפתיחה</translation>
    </message>
    <message>
        <source>User demo, password:</source>
        <translation type="vanished">משתמש demo, סיסמה:</translation>
    </message>
    <message>
        <source>Superuser root, password:</source>
        <translation type="vanished">משתמש על root, סיסמה:</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">שגיאה</translation>
    </message>
    <message>
        <source>About MX Welcome</source>
        <translation type="vanished">על תכנית קבלת הפנים של MX</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="vanished">גירסה:</translation>
    </message>
    <message>
        <source>Program for displaying a welcome screen in MX Linux</source>
        <translation type="vanished">תכנית להצגת מסך קבלת פנים ב־MX Linux</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">זכויות היוצרים (c) שמורות ל־MX Linux</translation>
    </message>
    <message>
        <source>License</source>
        <translation type="vanished">רשיון</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">יומן שינויים</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">ביטול</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;סגירה</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>You must run this program as normal user.</source>
        <translation type="vanished">יש להריץ את התכנית הזו כמשתמש רגיל.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>This tool displays a welcome screen with two tabs.</source>
        <translation type="vanished">הכלי הזה מציג מסך קבלת פנים עם שתי לשוניות.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="55"/>
        <source>This tool displays the MX Linux welcome screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="59"/>
        <source>Start with About selected. The About page provides basic information about the current MX Linux version, the user&apos;s hardware, and access to a full system report.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="61"/>
        <source>Run a test mode.</source>
        <translation>הרצת מסך בדיקה.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="82"/>
        <source>Error</source>
        <translation>שגיאה</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="83"/>
        <source>You must run this program as normal user.</source>
        <translation type="unfinished">יש להריץ את התכנית הזו כמשתמש רגיל.</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="67"/>
        <source>Open this tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
