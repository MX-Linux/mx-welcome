/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[24];
    char stringdata0[463];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 20), // "on_ButtonQSI_clicked"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 22), // "on_buttonAbout_clicked"
QT_MOC_LITERAL(4, 56, 27), // "on_buttonContribute_clicked"
QT_MOC_LITERAL(5, 84, 20), // "on_buttonFAQ_clicked"
QT_MOC_LITERAL(6, 105, 22), // "on_buttonForum_clicked"
QT_MOC_LITERAL(7, 128, 23), // "on_buttonManual_clicked"
QT_MOC_LITERAL(8, 152, 31), // "on_buttonPackageInstall_clicked"
QT_MOC_LITERAL(9, 184, 28), // "on_buttonPanelOrient_clicked"
QT_MOC_LITERAL(10, 213, 22), // "on_buttonSetup_clicked"
QT_MOC_LITERAL(11, 236, 20), // "on_buttonTOS_clicked"
QT_MOC_LITERAL(12, 257, 22), // "on_buttonTools_clicked"
QT_MOC_LITERAL(13, 280, 21), // "on_buttonTour_clicked"
QT_MOC_LITERAL(14, 302, 22), // "on_buttonVideo_clicked"
QT_MOC_LITERAL(15, 325, 21), // "on_buttonWiki_clicked"
QT_MOC_LITERAL(16, 347, 19), // "on_checkBox_clicked"
QT_MOC_LITERAL(17, 367, 7), // "checked"
QT_MOC_LITERAL(18, 375, 27), // "on_tabWidget_currentChanged"
QT_MOC_LITERAL(19, 403, 5), // "index"
QT_MOC_LITERAL(20, 409, 11), // "resizeEvent"
QT_MOC_LITERAL(21, 421, 13), // "QResizeEvent*"
QT_MOC_LITERAL(22, 435, 11), // "setTabStyle"
QT_MOC_LITERAL(23, 447, 15) // "shortSystemInfo"

    },
    "MainWindow\0on_ButtonQSI_clicked\0\0"
    "on_buttonAbout_clicked\0"
    "on_buttonContribute_clicked\0"
    "on_buttonFAQ_clicked\0on_buttonForum_clicked\0"
    "on_buttonManual_clicked\0"
    "on_buttonPackageInstall_clicked\0"
    "on_buttonPanelOrient_clicked\0"
    "on_buttonSetup_clicked\0on_buttonTOS_clicked\0"
    "on_buttonTools_clicked\0on_buttonTour_clicked\0"
    "on_buttonVideo_clicked\0on_buttonWiki_clicked\0"
    "on_checkBox_clicked\0checked\0"
    "on_tabWidget_currentChanged\0index\0"
    "resizeEvent\0QResizeEvent*\0setTabStyle\0"
    "shortSystemInfo"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  109,    2, 0x08 /* Private */,
       3,    0,  110,    2, 0x08 /* Private */,
       4,    0,  111,    2, 0x08 /* Private */,
       5,    0,  112,    2, 0x08 /* Private */,
       6,    0,  113,    2, 0x08 /* Private */,
       7,    0,  114,    2, 0x08 /* Private */,
       8,    0,  115,    2, 0x08 /* Private */,
       9,    0,  116,    2, 0x08 /* Private */,
      10,    0,  117,    2, 0x08 /* Private */,
      11,    0,  118,    2, 0x08 /* Private */,
      12,    0,  119,    2, 0x08 /* Private */,
      13,    0,  120,    2, 0x08 /* Private */,
      14,    0,  121,    2, 0x08 /* Private */,
      15,    0,  122,    2, 0x08 /* Private */,
      16,    1,  123,    2, 0x08 /* Private */,
      18,    1,  126,    2, 0x08 /* Private */,
      20,    1,  129,    2, 0x08 /* Private */,
      22,    0,  132,    2, 0x08 /* Private */,
      23,    0,  133,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   17,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, 0x80000000 | 21,    2,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_ButtonQSI_clicked(); break;
        case 1: _t->on_buttonAbout_clicked(); break;
        case 2: _t->on_buttonContribute_clicked(); break;
        case 3: _t->on_buttonFAQ_clicked(); break;
        case 4: _t->on_buttonForum_clicked(); break;
        case 5: _t->on_buttonManual_clicked(); break;
        case 6: _t->on_buttonPackageInstall_clicked(); break;
        case 7: _t->on_buttonPanelOrient_clicked(); break;
        case 8: _t->on_buttonSetup_clicked(); break;
        case 9: _t->on_buttonTOS_clicked(); break;
        case 10: _t->on_buttonTools_clicked(); break;
        case 11: _t->on_buttonTour_clicked(); break;
        case 12: _t->on_buttonVideo_clicked(); break;
        case 13: _t->on_buttonWiki_clicked(); break;
        case 14: _t->on_checkBox_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: _t->on_tabWidget_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->resizeEvent((*reinterpret_cast< QResizeEvent*(*)>(_a[1]))); break;
        case 17: _t->setTabStyle(); break;
        case 18: _t->shortSystemInfo(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 19;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
