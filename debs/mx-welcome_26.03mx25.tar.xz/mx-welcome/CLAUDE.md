# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build System

### Quick Build Commands
```bash
./build.sh           # Release build
./build.sh --debug   # Debug build  
./build.sh --clean   # Clean rebuild
./build.sh --debian  # Build Debian package
```

### Manual CMake Build
```bash
cmake -G Ninja -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
sudo cmake --install build
```

### Dependencies
- Qt6 (Core, Gui, Widgets, LinguistTools)
- C++20 compatible compiler (GCC 14+ or Clang)
- CMake 3.16+
- Ninja build system

## Architecture Overview

### Core Components
- **MainWindow** (`src/mainwindow.{h,cpp}`) - Main application window with tabbed interface
  - Welcome tab with resource links (MX Tools, Manual, Forum, Wiki, Videos, Contribute)
  - About tab with system information and hardware details
- **About** (`src/about.{h,cpp}`) - System information display and report generation
- **FlatButton** (`src/flatbutton.{h,cpp}`) - Custom button component for UI styling

### Key Features
- **Resource Links**: Launches external applications and web resources via `startDetached()` calls
- **System Information**: Hardware detection and MX Linux version reporting  
- **Auto-start Option**: Configurable login screen launch
- **Multi-language Support**: 40+ translations via Qt translation system

### Code Style
- C++20 with Qt6 framework
- Header guards using `#pragma once`
- Member variables use camelCase
- Commands stored as QString constants (TOOLSCMD, FORUMCMD, etc.)

## Translation System

### Qt Translations
- Source files: `translations/mx-welcome_*.ts`
- Handled automatically by CMake `qt6_add_translations()`
- Installed to `/usr/share/mx-welcome/locale/`

### Desktop File Translations
- Located in `translations-desktop-file/`
- Uses separate Makefile-based system for .desktop file localization
- Scripts: `get_translations`, `update-po-mo.sh`, `generate_desktop-in_files.sh`

## Command Integration
The application launches external MX tools and resources using `QProcess::startDetached()`. Command paths are configured in MainWindow constructor and stored as member variables like TOOLSCMD, MANUALCMD, etc.