Format: 3.0 (native)
Source: mx-welcome
Binary: mx-welcome
Architecture: any
Version: 26.03mx25
Maintainer: Adrian <adrian@mxlinux.org>
Homepage: https://github.com/AdrianTM/mx-welcome
Standards-Version: 4.5.1
Vcs-Git: git://github.com/AdrianTM/mx-welcome
Build-Depends: debhelper-compat (= 12), cmake (>= 3.16), ninja-build, qt6-base-dev, qt6-base-dev-tools, qt6-declarative-dev, qt6-tools-dev, qt6-tools-dev-tools
Package-List:
 mx-welcome deb admin optional arch=any
Checksums-Sha1:
 74cad125681ad8bd9239364e8a8568a0afbdc6e1 3071604 mx-welcome_26.03mx25.tar.xz
Checksums-Sha256:
 5af0c335355be9681da57b854fe5267fc718e0b375e8fe2127402d032ad5e3fa 3071604 mx-welcome_26.03mx25.tar.xz
Files:
 0f26bab94bafd568d00c5c2f9864cd8d 3071604 mx-welcome_26.03mx25.tar.xz
