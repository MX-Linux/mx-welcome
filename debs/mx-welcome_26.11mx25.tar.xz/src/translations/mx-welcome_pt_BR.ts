<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>Backend</name>
    <message>
        <location filename="../src/backend.cpp" line="73"/>
        <location filename="../src/backend.cpp" line="93"/>
        <location filename="../src/backend.cpp" line="116"/>
        <location filename="../src/backend.cpp" line="315"/>
        <source>Error</source>
        <translation>Ocorreu um erro</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="73"/>
        <source>Could not update the login startup setting.</source>
        <translation>Não foi possível salvar os ajustes de login.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="93"/>
        <source>Could not open %1</source>
        <translation>Não foi possível abrir %1</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="104"/>
        <source>System information is unavailable.</source>
        <translation>As informações do sistema não estão disponíveis.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="116"/>
        <source>Could not start Quick System Info.</source>
        <translation>Não foi possível abrir as Informações do Computador e do Sistema Operacional.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="127"/>
        <source>Could not load the Terms of Use.</source>
        <translation>Não foi possível abrir os Termos de Uso.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="134"/>
        <source>Could not load %1</source>
        <translation>Não foi possível carregar o %1</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="144"/>
        <source>Could not load changelog.</source>
        <translation>Não foi possível carregar o registro das alterações.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="194"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>O nome “MX Linux” é coberto pela Sublicença da Fundação Linux (Linux Foundation Sublicense) Número 20140605-0483. Nós desenvolvemos programas (software) que são cobertos por licença livre que podem ser examinadas na lista da Wiki. Também incluímos programas (software) desenvolvidos por terceiros que estão sob licença livre.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="205"/>
        <source>User demo, password: demo. Superuser root, password: root.</source>
        <translation>Usuário: ‘demo’, senha: ‘demo’.
Superusuário: ‘root’, senha: ‘root’.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="228"/>
        <source>%1 “%2”</source>
        <translation>%1 ‘%2’</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Install MX Linux</source>
        <translation>Instalar o MX Linux</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="262"/>
        <source>Install MX Linux on this computer.</source>
        <translation>Instalar o MX Linux neste computador.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="263"/>
        <source>FAQ</source>
        <translation>Perguntas frequentes sobre a instalação frugal</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="263"/>
        <source>Find answers to frequently asked questions.</source>
        <translation>Encontre respostas para perguntas comuns.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="264"/>
        <source>Forums</source>
        <translation>Fóruns</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="264"/>
        <source>Ask questions and join the MX Linux community.</source>
        <translation>Faça perguntas e junte-se à comunidade do MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="265"/>
        <source>Users Manual</source>
        <translation>Manual do Usuário</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="265"/>
        <source>Read the documentation for your MX Linux release.</source>
        <translation>Leia a documentação da sua versão do MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="266"/>
        <source>Videos</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="266"/>
        <source>Watch MX Linux tutorials and demonstrations.</source>
        <translation>Assista às demonstrações e tutoriais sobre o MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="267"/>
        <source>Wiki</source>
        <translation>Wiki</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="267"/>
        <source>Browse community-maintained guides and reference material.</source>
        <translation>Navegue por guias e materiais de referência mantidos por usuários.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="268"/>
        <source>Contribute</source>
        <translation>Contribuir</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="268"/>
        <source>Learn how to support and contribute to MX Linux.</source>
        <translation>Aprenda a como apoiar e contribuir com o MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="269"/>
        <source>Tools</source>
        <translation>Ferramentas</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="269"/>
        <source>Open the collection of MX system utilities.</source>
        <translation>Abra a coleção de ferramentas do MX.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="270"/>
        <source>Popular Apps</source>
        <translation>Aplicativos</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="270"/>
        <source>Discover and install popular applications.</source>
        <translation>Descubra e instale programas famosos.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="271"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="271"/>
        <source>Adjust desktop, panel, and system preferences.</source>
        <translation>Ajuste o painel, a área de trabalho e o sistema de acordo com a sua preferência.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="272"/>
        <source>Tour</source>
        <translation>Conheça o MX Linux</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="272"/>
        <source>Take a guided tour of MX Linux.</source>
        <translation>Uma apresentação guiada do MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/backend.cpp" line="315"/>
        <source>Could not start the requested action.</source>
        <translation>Não foi possível começar a ação solicitada.</translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="17"/>
        <location filename="../qml/Main.qml" line="103"/>
        <location filename="../qml/Main.qml" line="458"/>
        <source>MX Welcome</source>
        <translation>Seja Bem-Vindo(a) ao MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="136"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="146"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="119"/>
        <source>Welcome</source>
        <translation>Bem-vindo (a)</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="119"/>
        <location filename="../qml/Main.qml" line="295"/>
        <source>About this system</source>
        <translation>Sobre este sistema</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="258"/>
        <source>No actions are available.</source>
        <translation>Nenhuma ação disponível.</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="268"/>
        <source>Show this dialog at start up</source>
        <translation>Exibir esta janela na inicialização</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="312"/>
        <source>MX version</source>
        <translation>Versão do MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="313"/>
        <source>Debian version</source>
        <translation>Versão do Debian</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="314"/>
        <source>Desktop</source>
        <translation>Inicializar o Nemo ao iniciar a área de trabalho</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="315"/>
        <source>Supported until</source>
        <translation>Suportado até</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="341"/>
        <source>Unavailable</source>
        <translation>Indisponível</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="355"/>
        <location filename="../qml/Main.qml" line="371"/>
        <source>Short system report</source>
        <translation>Relatório resumido do sistema</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="366"/>
        <source>Loading system information…</source>
        <translation>Carregando informações do sistema...</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="381"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Relatório Completo de Informações Rápidas do Sistema Operacional</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="390"/>
        <location filename="../qml/Main.qml" line="399"/>
        <source>Terms of Use</source>
        <translation>Termos de Uso</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="425"/>
        <source>About MX Welcome</source>
        <translation>Sobre as Boas-Vindas do MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="466"/>
        <source>Version: %1</source>
        <translation>Versão: %1</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="472"/>
        <source>Program for displaying a welcome screen in MX Linux</source>
        <translation>Programa para exibir uma tela de boas-vindas no MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="479"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Direitos de Autor (c) do MX Linux</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="486"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="492"/>
        <source>MX Welcome License</source>
        <translation>Licença das Boas-vindas do MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="495"/>
        <location filename="../qml/Main.qml" line="501"/>
        <source>Changelog</source>
        <translation>Relatório das Alterações</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/ui_mainwindow.h" line="573"/>
        <source>MX Welcome</source>
        <translation>Bem-vindo (a) ao MX Linux</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="576"/>
        <source>Quit application</source>
        <translation>Sair do aplicativo</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="578"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="580"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="583"/>
        <source>About this application</source>
        <translation>Sobre este aplicativo</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="585"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="587"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="589"/>
        <source>Install MX Linux</source>
        <translation>Instalar o MX Linux</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="590"/>
        <source>Tweak (Panel, etc...)</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="591"/>
        <source>Tools</source>
        <translation>Ferramentas</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="592"/>
        <source>Wiki</source>
        <translation>Wiki</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="593"/>
        <source>Users Manual</source>
        <translation>Manual do Usuário</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="594"/>
        <source>FAQ</source>
        <translation>Perguntas Frequentes</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="595"/>
        <source>Tour</source>
        <translation>Conheça o MX Linux</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="596"/>
        <source>Popular Apps</source>
        <translation>Aplicativos</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="597"/>
        <source>Contribute</source>
        <translation>Contribuir</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="598"/>
        <source>Videos</source>
        <translation>Vídeos</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="599"/>
        <source>Forums</source>
        <translation>Fóruns</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="600"/>
        <source>Welcome</source>
        <translation>Bem-vindo (a)</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="601"/>
        <source>DESKTOP</source>
        <translation>ÁREA DE TRABALHO</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="603"/>
        <source>Quick-System-Info Full Report</source>
        <translation>Relatório Completo de Informações Rápidas do Sistema Operacional</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="604"/>
        <source>Terms of Use</source>
        <translation>Termos de Uso</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="606"/>
        <source>The name “MX Linux” is covered by Linux Foundation Sublicense No. 20140605-0483. We develop software that is covered by a free license that can be examined in the Wiki list. We also include software developed by others that is under a free license.</source>
        <translation>O nome “MX Linux” é coberto pela Sublicença da Fundação Linux (Linux Foundation Sublicense) Número 20140605-0483. Nós desenvolvemos programas (software) que são cobertos por licença livre que podem ser examinadas na lista da Wiki. Também incluímos programas (software) desenvolvidos por terceiros que estão sob licença livre.</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="607"/>
        <source>MX VERSION</source>
        <translation>VERSÃO DO MX LINUX</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="608"/>
        <source>DEBIAN VERSION:</source>
        <translation>VERSÃO DO DEBIAN:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="609"/>
        <source>SUPPORTED UNTIL:</source>
        <translation>SUPORTE ATÉ:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="611"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10.5pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans&apos;; font-size:12pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10.5pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="620"/>
        <source>SHORT SYSTEM REPORT:</source>
        <translation>RELATÓRIO RESUMIDO DO SISTEMA OPERACIONAL:</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="621"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../src/ui_mainwindow.h" line="622"/>
        <source>Show this dialog at start up</source>
        <translation>Exibir esta janela ao iniciar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="74"/>
        <source>This tool displays the MX Linux welcome screen.</source>
        <translation>Este recurso mostra a Tela de Boas-vindas do MX Linux.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="78"/>
        <source>Start with About selected. The About page provides basic information about the current MX Linux version, the user&apos;s hardware, and access to a full system report.</source>
        <translation>Comece com o ‘Sobre’ selecionado. A página ‘Sobre’ contêm informações úteis sobre a versão atual do MX Linux, o computador do usuário e acesso a relatórios completos sobre o sistema.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="80"/>
        <source>Run a test mode.</source>
        <translation>Executar com o modo de teste.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="101"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>You must run this program as normal user.</source>
        <translation>Você tem que executar este programa como um usuário normal.</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="69"/>
        <source>Open this tool</source>
        <translation>Abrir esta ferramenta</translation>
    </message>
</context>
</TS>
